import React from 'react';
import { Button, Col, Container, Row } from 'react-bootstrap';
import './HomePage.css'
import 'bootstrap/dist/css/bootstrap.min.css';

export default class HomePage extends React.Component {
    render() {

        return (
            <div className="mb-2">
                <Container>
                    <Row>
                        <Col>

                        </Col>
                    </Row>

                </Container>

                <Container fluid="md">
                    <Row className="rounded-2">

                        <Col lg={4}>
                                Name of the Website
                        </Col>

                        <Col lg={4}>
                            <Button variant="outline-danger" size="lg">
                                Levels
                            </Button>
                        </Col>

                        <Col lg={4}>
                            <Button variant="outline-danger" size="lg">
                                <img className="img100" alt="some stuff" src="logo192.png"></img>
                            </Button>
                            <Button variant="outline-danger" size="lg">
                                Time
                            </Button>
                            <Button variant="outline-danger" size="lg">
                                Time
                            </Button>
                        </Col>

                    </Row>
                </Container>
                <Container>
                    <head>Hi</head>
                </Container>

            </div>
        );
    }
}